#' tonytianHW4.
#'
#' @name tonytianHW4
#' @docType package
#' @author Tong Tian
#' @import Rcpp
#' @importFrom Rcpp evalCpp
#' @useDynLib tonytianHW4
#' @name tonytianHW4
NULL
